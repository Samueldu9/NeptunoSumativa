/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neptuno;

import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MejoresClientes {
    private String user;
    private String password;
    private String db;
    private String host;
    private String url;
    private Connection conn=null;
    private Statement stm;
    
public MejoresClientes(String usuario, String contraseña, String bd, String servidor)
{
    this.user = usuario;
    this.password = contraseña;
    this.db=bd;
    this.host=servidor;
    this.url = "jdbc:mysql://" + this.host + "/" + this.db + "?useSSL=false&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
}

public void conectarMejoresClientes()
{
    try {
            Class.forName("com.mysql.cj.jdbc.Driver");//com.mysql.cj.jdbc.Driver
            conn = DriverManager.getConnection(url, user, password);
            if (conn != null) {
                System.out.println("Conexión a base de datos " + url + " ... Ok");
                stm = conn.createStatement();
            }
        } catch (SQLException ex) {
            System.out.println("Problema en la conexión a la base de datos " + url);
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);
        }
}

public void cerrarMejoresClientes()
{
    try {
            if (conn != null) {
                stm.close();
                conn.close();
                System.out.println("Conexión cerrada");
            }
        } catch (SQLException ex) {
            System.out.println(ex);
        }
}

public ResultSet mejoresClientes() throws SQLException
{
    return stm.executeQuery("select c.nombreCompañía, sum(d.cantidad*d.precioUnidad) from clientes as c, pedidos as p, `detalles de pedidos` as d, \n" +
"					productos as x where c.idCliente=p.idCliente and p.idPedido=d.idPedido and d.idProducto=x.idProducto\n" +
"					group by c.idCLiente order by sum(d.cantidad*d.precioUnidad) desc limit 10");
}
    


ResultSet ventasCategoria(String fecha1,String fecha2) throws SQLException 
    {
        return stm.executeQuery("select c.nombreCategoría, sum(d.cantidad * d.precioUnidad) from Categorías as c, Productos as p, `Detalles de pedidos` as d, pedidos as x where c.idCategoría = p.idCategoría and p.idProducto = d.idProducto and d.idPedido = x.idPedido and x.fechaPedido between '"+fecha1+"' and '"+fecha2+"' group by c.nombreCategoría");
    }

}