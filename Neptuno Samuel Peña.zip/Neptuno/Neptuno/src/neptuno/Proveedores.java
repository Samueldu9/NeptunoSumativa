/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package neptuno;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author samue
 */
public class Proveedores {
     private String user;
    private String password;
    private String db;
    private String host;
    private String url;
    private Connection conn = null;
    private Statement stm;// permite guardar comandos SQL
    public Proveedores(String usuario,String contra,String bd, String servidor)
    {
        this.user = usuario;
        this.password = contra;
        this.db = bd;
        this.host = servidor;
        this.url = "jdbc:mysql://" + this.host + "/" + this.db;
	//quitar el comentario cuando se usa MySql 8 y superior
	//this.url = "jdbc:mysql://" + this.host + "/" + this.db+"?useSSL=false&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    }
    public void conectar()
    {
      try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(url, user, password);
                if (conn != null)
                {
                    System.out.println("Conexi�n a base de datos "+url+" ... Ok");
                    stm = conn.createStatement();
                }
            }   
        catch(SQLException ex) {
            System.out.println("Problema en la conexión a la base de datos "+url);
        }
        catch(ClassNotFoundException ex) {
            System.out.println(ex);
        }
    }
    public void cerrar()
    {
        try{
            if(conn !=null){
                stm.close();
                conn.close();
                System.out.println("Conexi�n cerrada");
            }
        }
        catch(SQLException ex){
            System.out.println(ex);
        }
    }public String guardarProveedor(String idProveedor, String NombreContacto,String NombreCompa, String Cargo, String Dir,String Ciudad, String Region, String CodPost, String Pais,String Telf, String Fax)
    {
        try 
        {
            stm.execute("INSERT INTO Proveedores values('"+idProveedor+"','"+NombreContacto+"','"+NombreCompa+"','"+Cargo+"','"+Dir+"','"+Ciudad+"','"+Region+"','"+CodPost+"','"+Pais+"','"+Telf+"','"+Fax+"')");
            return ("Registro guardado!");
        } catch (SQLException ex) 
        {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ("No se guardo el registro...");
    }
    public String modificarProveedor (String idProveedor, String NombreContacto,String NombreCompa, String Cargo, String Dir,String Ciudad, String Region, String CodPost, String Pais,String Telf, String Fax)
    {
        try {
            stm.execute("update Proveedores set NombreCompañía='"+NombreCompa+"',CargoContacto='"+Cargo+"',Dirección='"+Dir+"',Ciudad='"+Ciudad+"',Región='"+Region+"',CódPostal='"+CodPost+"',País='"+Pais+"',Teléfono='"+Telf+"',Fax='"+Fax+"')");
            return ("Se modifico el registro");
        } catch (SQLException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
        return("No se modifico");
    }
    public String eliminarProveedor (String idProveedor)
    {
        try {
            stm.execute("delete from Proveedores where idProveedores ='"+idProveedor+"'");
            return("Refistro eliminado");
        } catch (SQLException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
            return ("No se elimino el registro");
        }
    }
    public ResultSet consultarPorId (String id)throws SQLException
    {
            return stm.executeQuery("select *from Proveedores where idProveedor like'"+id+"%'");
    }
    public ResultSet consultarPorCompania (String compania)throws SQLException
    {
        return stm.executeQuery("select *from Proveedores where NombreCompañía like'"+compania+"%'");
    }
}
